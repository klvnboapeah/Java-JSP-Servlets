/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet_pkg;

import java.util.Properties;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author Kelvin_B
 */
public class SendEmail {
        
    /*
    * This function sends out an email to an email. It returns true if the email is successfully sent, or false if otherwise
    * @param to The recipient of the email
    * @param from The sender of the email
    * @param subject The subject of the email
    * @param body The body of the email
    * @param bodyIsHTML A flag used to determine if the email contains HTML or text
    */
    public static boolean sendMail(String to, String from, String subject, String body, boolean bodyIsHTML) 
            throws MessagingException {
        try{
            //1 - get a mail session
            Properties props = new Properties();
            props.put("mail.transport.protocol", "smtps");//"mail" (e.g. mail.example.com).klvnboapeah.com
            props.put("mail.smtps.host", "mail.klvnboapeah.com"); //smtp.gmail.com
            props.put("mail.smtps.port", 465);
            props.put("mail.smtps.auth", "true");
            props.put("mail.smtps.quitwait", "false");
            Session session = Session.getDefaultInstance(props);
            session.setDebug(true);

            // 2 - create a message
            Message message = new MimeMessage(session);
            message.setSubject(subject);
            if (bodyIsHTML) {
                message.setContent(body, "text/html");
            } else {
                message.setText(body);
            }

            // 3 - address the message
            Address fromAddress = new InternetAddress(from);
            Address toAddress = new InternetAddress(to);
            message.setFrom(fromAddress);
            message.setRecipient(Message.RecipientType.TO, toAddress);

            // 4 - send the message
            Transport transport = session.getTransport();
            //transport.connect("klvnboapeah@gmail.com", "(Escalade3)");
            transport.connect("portfolio_website@klvnboapeah.com", "(Escalade2)");
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
        }
        catch(Exception ex){return false;}
        return true;
    }
}
