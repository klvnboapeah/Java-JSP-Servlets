/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet_pkg;
import java.util.ArrayList;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class Sax_Parser_Handler extends DefaultHandler {

    //List to hold Profile object
    private List<Profile> profileList = null;
    private Profile profile = null;


    //getter method for profile list
    public List<Profile> getprofileList() {
        return profileList;
    }

    boolean b_username = false;
    boolean b_password = false;
    boolean b_email = false;

    /**
     *
     * @param uri
     * @param localName
     * @param qName
     * @param attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes)
            throws SAXException {

        if (qName.equalsIgnoreCase("Profile")) {
            //create a new Profile and put it in Map
            String id = attributes.getValue("id");
            //initialize Profile object and set id attribute
            profile = new Profile();
            profile.setId(Integer.parseInt(id));
            //initialize list
            if (profileList == null)
                profileList = new ArrayList<>();
        } else if (qName.equalsIgnoreCase("username")) {
            //set boolean values for fields, will be used in setting Profile variables
            b_username = true;
        } else if (qName.equalsIgnoreCase("password")) {
            b_password = true;
        } else if (qName.equalsIgnoreCase("email")) {
            b_email = true;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equalsIgnoreCase("Profile")) {
            //add Employee object to list
            profileList.add(profile);
        }
    }

    @Override
    public void characters(char ch[], int start, int length) throws SAXException {

        if (b_username) {
            //username element, set Profile username
            profile.setUserName(new String(ch, start, length));
            b_username = false;
        } 
        else if (b_password) {
            profile.setPassword(new String(ch, start, length));
            b_password = false;
        }
        else if (b_email) {
            profile.setEmail(new String(ch, start, length));
            b_email = false;
        }
    }
}