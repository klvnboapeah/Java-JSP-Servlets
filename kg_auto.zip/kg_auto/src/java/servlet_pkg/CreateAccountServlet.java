/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet_pkg;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXException;

/**
 *
 * @author Kelvin_B
 */
public class CreateAccountServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String error = "", username = "", password = "", retype_password = "", email = "";
            //----------------------------------------------------------------------------------
            username = request.getParameter("username").trim();
            email = request.getParameter("email").trim();
            password = request.getParameter("password").trim();
            retype_password = request.getParameter("retype_password").trim();
            //-----------------------------------------------------------------------------------
            
            if (username.isEmpty()){
                error += "|username|";
            }
            if(email.isEmpty()){
                error += "|email|";
            }
            if(password.isEmpty()){
                error += "|password|";
            }
            if(retype_password.isEmpty()){
                error += "|retype_password|";
            }
            if(!password.isEmpty() && !retype_password.isEmpty() && 
                    !retype_password.equals(password)){
                error += "<passwords do not match>";
            }
            
            if(error.isEmpty()){
                //--------------------------------------------------------------
                SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
                //InputStream xmlInput = new FileInputStream("C:\\Users\\Kelvin_B\\Documents\\NetBeansProjects\\kg_auto\\src\\java\\servlet_pkg\\userprofiles.xml");
                InputStream xmlInput = new FileInputStream(new File(this.getClass().getClassLoader().getResource("").getPath()+"servlet_pkg/userprofiles.xml"));
                SAXParser saxParser = null;
                try {
                    saxParser = saxParserFactory.newSAXParser();
                } catch (ParserConfigurationException ex) {
                    Logger.getLogger(CreateAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SAXException ex) {
                    Logger.getLogger(CreateAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
                Sax_Parser_Handler saxHandler = new Sax_Parser_Handler();
                try {
                    saxParser.parse(xmlInput, saxHandler);
                } catch (SAXException ex) {
                    Logger.getLogger(CreateAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            
                //Get Profile List
                List<Profile> profile_list = saxHandler.getprofileList();
                //print profile information
                for(Profile pf : profile_list){
                    if(pf.getUserName().equals(request.getParameter("username")) &&
                            pf.getPassword().equals(request.getParameter("password"))){
                        out.println("success");
                        break;
                    }
                    else{
                        out.println("fail");
                        break;
                    }
                };
               
                //--------------------------------------------------------------
                
                
                out.println("|success|");
            }
            else{
                out.println(error);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
