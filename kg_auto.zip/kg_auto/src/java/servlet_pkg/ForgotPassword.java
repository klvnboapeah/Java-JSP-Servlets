/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet_pkg;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

/**
 *
 * @author Kelvin_B
 */
public class ForgotPassword extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String eMail = request.getParameter("email");
            String userName = request.getParameter("username_2");
            
            eMail = eMail.trim();
            userName = userName.trim();
            Profile user_profile = findUser(userName, eMail);
            if(user_profile.getEmail() == null || user_profile.getUserName() == null){
                out.println(0);}
            else{
                boolean sent_status = false;
                sent_status = SendEmail.sendMail(user_profile.getEmail(),"portfolio_website@klvnboapeah.com", "KLVNBOAPEAH.COM - CONTACT ME", composeMessage(user_profile), true);        
                out.println(1);
            }
            //boolean sent_status = SendEmail.sendMail(eMail,"portfolio_website@klvnboapeah.com", "KLVNBOAPEAH.COM - CONTACT ME", email_message + userName, true);        
        }
        catch(Exception e){
            PrintWriter out_exception = response.getWriter();
            out_exception.println(2);
        }
    }
    
    /*
    * This function composes an email
    * @param person The profile of the person who signed in
    */
    private String composeMessage(Profile person){
        String tempStr = "Greetings, <br> " +
                "<ol>"+
                    "<li>Username: "+ person.getUserName() + "</li>"+
                    "<li>Password: " + person.getPassword() + "</li>" + 
                "</ol>";
        return tempStr;
    }
    
    
    private Profile findUser(String username, String emailAddress){
        Profile userProfile = new Profile();
        
        try{
            SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
            //InputStream xmlInput = new FileInputStream("C:\\Users\\Kelvin_B\\Documents\\NetBeansProjects\\kg_auto\\src\\java\\servlet_pkg\\userprofiles.xml");
            InputStream xmlInput = new FileInputStream(new File(this.getClass().getClassLoader().getResource("").getPath()+"servlet_pkg/userprofiles.xml"));
            SAXParser saxParser = saxParserFactory.newSAXParser();
            Sax_Parser_Handler saxHandler = new Sax_Parser_Handler();
            saxParser.parse(xmlInput, saxHandler);
            
            //Get Profile List
            List<Profile> profile_list = saxHandler.getprofileList();
            //print profile information
            for(Profile pf : profile_list){
                if(pf.getEmail().equals(emailAddress) && pf.getUserName().equals(username)){
                    userProfile.setUserName(username);
                    userProfile.setEmail(emailAddress);
                    userProfile.setPassword(pf.getPassword());
                    break;
                }
            };
        }
        catch (Exception ex){
            return userProfile;
        }
        return userProfile;
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
