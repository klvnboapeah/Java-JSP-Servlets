/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Kelvin Boapeah 
 * Java Bean
*/
package servlet_pkg;

public class Profile {
    private int id;
    private String username;
    private String password;
    private String email;
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getUserName() {
        return username;
    }
    public void setUserName(String usernam) {
        this.username = usernam;
    }
    public String getPassword() {
        return password;
    }
    
    /*
    * Sets the password of the current user profile
    * @param passwd The new password to be set
    */
    public void setPassword(String passwd) {
        this.password = passwd;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    
    @Override
    public String toString() {
        return "Profile:: ID="+this.id+" Name=" + this.username + " Password=" + this.password + " Email=" + this.email;
    }  
}
